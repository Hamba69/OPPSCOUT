export type PreferredChannel = "web" | "email" | "sms" | "ussd";
export type NotificationFrequency = "instant" | "daily" | "weekly";
export type WorkMode = "remote" | "onsite" | "hybrid";
export type VerificationStatus = "unverified" | "pending" | "verified" | "flagged";
export type OpportunitySource = "org_submitted" | "scraped" | "partner_feed";
/** How the listing entered OppScout; separate from the source of its information. */
export type OpportunityOrigin = "catalog" | "organization";
/** `fixed` closes on `deadline`; `rolling` has no closing date but must be re-checked regularly. Absent means `fixed`. */
export type DeadlineType = "fixed" | "rolling";
export type OpportunityStatus = "open" | "closing_soon" | "closed" | "stale" | "removed";
export type SavedStatus = "saved" | "applied" | "expired";
export type SubscriptionTier = "free" | "growth" | "partner";
export type SubscriptionStatus = "inactive" | "trial" | "active" | "past_due" | "cancelled";
export type EventType = "view" | "save" | "click" | "apply_intent" | "report";

export interface ExperienceEntry {
  title: string;
  organization?: string;
  months: number;
}

export interface ProfileLink {
  label: string;
  url: string;
}

export interface ProfileProject {
  title: string;
  description: string;
  url?: string;
  role?: string;
  tags: string[];
}

export interface Eligibility {
  additionalRequirements?: string[];
  educationLevels?: string[];
  fieldsOfStudy?: string[];
  minimumExperienceMonths?: number;
  minimumAge?: number;
  maximumAge?: number;
  mandatoryCertifications?: string[];
  programmeRules?: Array<{
    field: "graduationStatus" | "location" | "language";
    allowedValues: string[];
    label: string;
  }>;
}

export interface UserProfile {
  id: string;
  name: string;
  phone: string | null;
  email: string | null;
  preferredChannel: PreferredChannel;
  secondaryChannels: PreferredChannel[];
  notificationsEnabled: boolean;
  notificationFrequency: NotificationFrequency;
  educationLevel: string | null;
  institution: string | null;
  fieldOfStudy: string | null;
  graduationStatus: string | null;
  dateOfBirth: Date | null;
  skills: string[];
  workExperience: ExperienceEntry[];
  internshipExperience: ExperienceEntry[];
  certifications: string[];
  location: string | null;
  preferredLocations: string[];
  careerInterests: string[];
  opportunityCategories: string[];
  workModePreference: WorkMode | null;
  languages: string[];
  githubUrl: string | null;
  portfolioUrl: string | null;
  otherLinks: ProfileLink[];
  projects: ProfileProject[];
  shareWithOrganizations: boolean;
  shareContactDetails: boolean;
  orgSharingConsentAt: Date | null;
  orgSharingConsentVersion: string | null;
  profileCompletenessScore: number;
  createdAt: Date;
  updatedAt: Date;
}

export interface AccountableContact {
  name: string;
  phone: string;
}

export interface Organization {
  id: string;
  name: string;
  sector: string;
  officialLinks: string[];
  officialEmail: string | null;
  registrationProof: string | null;
  accountableContact: string | null;
  accountableContacts?: AccountableContact[];
  additionalAccountableContact?: string | null;
  additionalAccountableContactPhone?: string | null;
  verificationStatus: VerificationStatus;
  dashboardUsers: string[];
  postingHistory: Array<{ opportunityId: string; postedAt: string }>;
  createdAt: Date;
  updatedAt: Date;
  subscriptionTier: SubscriptionTier;
  subscriptionStatus: SubscriptionStatus;
  monetizationEnabled: boolean;
  promotedListingCredits: number;
  promotionPolicy: Record<string, unknown>;
}

export interface TrustChecklist {
  sourceAuthentic: boolean;
  officialApplicationLink: boolean;
  eligibleForUgandans: boolean;
  noInappropriateFees: boolean;
  noSensitiveDataAsk: boolean;
  deadlinePlausible: boolean;
  duplicateChecked: boolean;
}

export interface Opportunity {
  id: string;
  title: string;
  organizationId: string | null;
  organizationName?: string | null;
  organization?: Pick<Organization, "id" | "name" | "verificationStatus">;
  category: string;
  description: string;
  eligibility: Eligibility;
  requiredSkills: string[];
  preferredSkills: string[];
  location: string;
  workMode: WorkMode | "unknown";
  deadline: Date | null;
  deadlineType?: DeadlineType;
  applicationMethod: string;
  sourceUrl: string;
  verificationStatus: VerificationStatus;
  source: OpportunitySource;
  origin?: OpportunityOrigin;
  publicationDate: Date;
  checkedAt: Date;
  status: OpportunityStatus;
  reviewChecklist: Partial<TrustChecklist>;
  reviewNotes: string | null;
  reviewerId: string | null;
  reviewedAt: Date | null;
}

export interface SavedOpportunity {
  id: string;
  userId: string;
  opportunityId: string;
  status: SavedStatus;
  reminderSent: boolean;
  createdAt: Date;
  updatedAt: Date;
}

export interface EventLog {
  id: string;
  eventType: EventType;
  userId: string | null;
  opportunityId: string | null;
  timestamp: Date;
  metadata: Record<string, unknown>;
}
