# Agent prompt: legal pages and consent experience for OppScout

Paste everything below into your agent, from a checkout of the OppScout repo. Put the seven files from `oppscout-legal/` (six policies plus this prompt) in the repo first: the policies go to `content/legal/`.

---

You are working in the OppScout repository (Next.js, Prisma, Supabase Auth, Tailwind). Your job is to add the legal documents and an interactive consent experience to the landing page and sign-up flow. Do the whole job, in the order given, and do not call a step finished until its checks pass.

## 0. Read before you write

1. `AGENTS.md` and `CLAUDE.md` say this is not the Next.js you know. Read the relevant guides in `node_modules/next/dist/docs/` before touching routing, metadata, cookies or server components.
2. Read `src/app/(web)/page.tsx` (landing), `src/app/layout.tsx`, `src/components/auth-form.tsx`, `src/components/settings-form.tsx`, `src/proxy.ts`, `src/lib/repository/*` (types, prisma, supabase, memory), `prisma/schema.prisma`, the migrations from `20260919000000_enable_public_rls` onward, `scripts/check-rls.ts`, `tests/contract/routes.contract.test.ts`, `tailwind.config.ts` and `src/app/globals.css`.
3. Match the existing design language: Montserrat, the `cream / butter / amber / honey / ink / navy / leaf / coral` tokens, `.card`, `.button`, `.field`, `.label`, `.page-shell`, `rounded-blob`, 44px minimum touch targets (`min-h-11`). Do not introduce a new visual style.

## 1. The documents

Copy these into `content/legal/` unchanged apart from the placeholders: `privacy-policy.md`, `terms-of-use.md`, `cookie-policy.md`, `messaging-terms.md`, `ai-matching-notice.md`, `your-data-rights.md`. Each starts with front matter (`title`, `slug`, `version`, `effective`, `required`, `summary`).

Placeholders use `{{TOKEN}}` syntax. Create `src/config/legal.ts` exporting a single typed object with these tokens and fill from environment variables with safe fallbacks. Replace tokens at render time, never by editing the markdown.

`LEGAL_ENTITY, POSTAL_ADDRESS, CONTACT_EMAIL, PDPO_REG_NO, DPO_NAME, EFFECTIVE_DATE, APP_URL (use appUrl() from src/config/app.ts), USSD_CODE, EMAIL_FROM (use OPPSCOUT_EMAIL_FROM), DAILY_CAP (use notificationDailyCap()), SUPABASE_PROJECT_REF (derive from NEXT_PUBLIC_SUPABASE_URL), REPORT_RETENTION, LOG_RETENTION, INACTIVE_RETENTION, BACKUP_RETENTION`

Add the new variable names to `.env.example` and to `scripts/validate-production-env.mjs` so a production build **fails** if any token is unset. In development, show a visible `[SET LEGAL_...]` marker instead of silently blanking. Never ship a page with a raw `{{...}}` visible.

Expose a version registry, `LEGAL_VERSIONS`, read from the front matter, so changing a document's `version` automatically triggers re-consent (section 4).

## 2. Public legal pages

- Routes: `/legal` (index of all six, with each summary line) and `/legal/[slug]`. They must be public: do not add them to the `matcher` in `src/proxy.ts`.
- Render markdown to accessible HTML (headings, tables, lists, links). Use one small, well-maintained markdown library (or the repo's existing one if present), and sanitise output. Tables must scroll horizontally inside their own container on narrow screens.
- Each page shows title, version, effective date, a table of contents built from `##` headings, and a "Back to sign up" link. Set per-page `metadata` (title via the existing `%s · OppScout` template).
- Add a footer to the landing page and to the bottom of `/login` with links to Privacy, Terms, Cookies, Messaging, and a "Cookie settings" button that reopens the consent panel.

## 3. The interactive consent experience on the landing page

Build a client component, `ConsentGate`, and place it on `src/app/(web)/page.tsx` directly above the existing "Get started" button, replacing that button's behaviour as follows. The "I already have an account" link stays exactly as it is and is never gated.

### Items

| id | Label (user-facing) | Document | State |
|---|---|---|---|
| `terms` | I accept the Terms of Use | terms-of-use | **required** |
| `privacy` | I have read the Privacy Policy and agree to how my data is used | privacy-policy | **required** |
| `age` | I am 18 or older | none | **required** |
| `messaging` | Send me alerts by email, SMS or USSD about opportunities | messaging-terms | optional, unticked |
| `analytics` | Share anonymous usage and speed statistics to help improve OppScout | cookie-policy | optional, unticked |

The cookie policy and AI notice are linked from the footer of the gate ("Cookie Policy", "How matching works") as information, without a checkbox, because essential cookies need no consent and AI matching is off.

### Behaviour

1. **"Agree to all" master checkbox** at the top. Ticking it ticks every item, including the optional ones. Unticking it clears all. It shows the indeterminate state (`input.indeterminate = true` through a ref, with `aria-checked="mixed"`) when only some are ticked. Label it honestly: "Agree to all (including optional alerts and statistics)".
2. **Each row** is a native `<input type="checkbox">` with a real `<label>`, plus a **"Read"** button (not a link that navigates away). "Read" opens the document in a modal using the native `<dialog>` element: focus moves into it, Escape closes it, focus returns to the triggering button, the page behind does not scroll, and the dialog content scrolls internally. Inside the dialog show the rendered document, its version and date, an "Open full page" link to `/legal/[slug]`, and a bottom bar with **"I have read this"** (closes) and, for required items, **"Accept and close"** (ticks the item and closes).
3. Do not force scrolling to the bottom before accepting. Do not pre-tick anything. Do not hide or shrink the path that accepts only the required items. Both paths must be equally prominent. No dark patterns.
4. **Primary button.** Disabled until all three required items are ticked. Its label changes with state: "Accept the 3 required items to continue" when incomplete, "Continue" with required only, "Continue with all" when every item is ticked. When disabled, an `aria-describedby` message names exactly which required items are missing. A click navigates to `/profile` (which redirects to login with `next`), as today.
5. **Persistence.** On every change, write a first-party cookie `oppscout_consent` (path `/`, `SameSite=Lax`, `Secure` in production, 12 months) containing JSON: `{ v: 1, docs: { "terms-of-use": "1.0.0", "privacy-policy": "1.0.0", ... }, optional: { messaging: boolean, analytics: boolean }, age: true, at: ISO timestamp }`. Read it on mount so returning visitors see their choices pre-filled with the "Continue" button ready. If any stored document version is older than `LEGAL_VERSIONS`, show a compact notice, "We updated our Terms / Privacy Policy", with Read and re-accept for those items only.
6. **Accessibility.** Wrap the list in `<fieldset>` with a `<legend>`. Announce state changes through an `aria-live="polite"` region ("2 of 3 required items accepted"). Ensure full keyboard operation, visible focus rings, contrast at least WCAG AA against the cream and butter backgrounds, and respect `prefers-reduced-motion` (no animated modal entrance when set). Test at 360px width, since most users are on phones.
7. **Micro-interaction.** A progress ring or bar showing required items accepted (0/3 to 3/3) that turns `leaf` green when complete. Keep it light; no confetti.
8. Copy should be warm and brief, in the voice of the landing page ("Your next step should feel safe."). Put a one-line summary under each label, taken from the front matter `summary`.

### Sign-up flow

People can reach `/login` directly, so the same consent must be enforced at account creation. Render a compact variant of `ConsentGate` inside `AuthForm` when `mode === "signup"`. If a valid `oppscout_consent` cookie already exists, show the accepted items as a read-only summary with "Change" and let the person proceed. Disable "Create account" until the required items are accepted. Do not require consent to sign in.

## 4. Server-side record of consent

Consent in a cookie is not evidence. Store it.

1. Add a Prisma model `ConsentRecord`: `id (uuid)`, `userId (uuid, FK UserProfile, onDelete Cascade)`, `documentSlug`, `documentVersion`, `granted (boolean)`, `source (enum: web | ussd)`, `createdAt`. Index on `(userId, documentSlug, createdAt)`. The table is **append-only**: a withdrawal inserts a new row with `granted = false`; never update or delete rows except by account-deletion cascade. Do not store IP addresses or user agents.
2. Create the migration following the pattern of the existing migrations, including RLS and the server-only data API access, then extend `scripts/check-rls.ts` so it covers the new table.
3. Extend the `Repository` interface and implement it in **all three** adapters (`prisma`, `supabase`, `memory`).
4. New routes, behind `requireAuth`, with zod validation in `src/lib/validation.ts`, `apiHandler`, rate limiting and `Cache-Control: private, no-store`, matching the existing route style:
   - `POST /api/v1/consent` takes the cookie payload and writes one row per document and per optional item.
   - `GET /api/v1/consent` returns the latest state per document and the list of documents whose accepted version is stale.
5. Sync: after sign-in or confirmed sign-up, if an `oppscout_consent` cookie is present and the server has no matching rows, post it automatically. Do this from the `/auth/callback` route and from the client after password sign-in. A failed sync must never block sign-in; retry on the next page load.
6. Gate: a signed-in user whose required documents are missing or stale sees a blocking `ConsentGate` in modal form on their next page (the `(web)` and `(dashboard)` layouts), and cannot continue until they accept. This is how a version bump reaches existing users. Browsing `/legal/*` stays open throughout.
7. The messaging item feeds the existing preferences: if the user declines `messaging`, then `notificationsEnabled` must be false and the notification worker must not send email, SMS or USSD to them. Add a guard and a test for this. In-app notifications are unaffected.

## 5. Gate telemetry on consent

`src/app/layout.tsx` currently renders `<Analytics />` and `<SpeedInsights />` unconditionally. Replace them with a client component, `ConsentAwareTelemetry`, that renders them only when `oppscout_consent.optional.analytics === true`, and stops rendering them when the choice changes (listen for a custom `oppscout:consent-changed` event dispatched by `ConsentGate`, so no reload is needed).

## 6. Settings: manage consent after the fact

Add a "Privacy and consent" card to `src/app/(web)/settings/page.tsx`:

- Toggles for messaging and analytics, writing new `ConsentRecord` rows and updating the cookie.
- The list of accepted documents with version and date, each with a Read button reusing the dialog.
- Links to Your Data Rights, with two clear buttons: "Ask for a copy of my data" and "Delete my account", each opening a prefilled `mailto:` to `CONTACT_EMAIL` with the subject lines used in `your-data-rights.md` (self-serve deletion is out of scope for this task). Do not describe an action as done when it only opens an email.

## 7. USSD

On a first USSD session for a phone number with no consent record, show a short consent step before the menu, within the existing 182-character budget (`src/ussd/character-budget.ts`). Suggested copy: `OppScout. By continuing you accept our Terms and Privacy Policy at {{short link}}. 1 Accept 2 Exit`. Choosing 1 writes `ConsentRecord` rows with `source = ussd` for terms and privacy. Alerts by SMS stay off until the user turns them on. Add this to `menu-tree.ts` with unit tests and confirm the character budget test still passes.

## 8. Tests and checks

- Unit (Vitest): master checkbox logic including the indeterminate state; button disabled and labels per state; cookie read, write and version-stale detection; placeholder replacement fails when a token is missing; the notification guard for declined messaging.
- Contract: add `/api/v1/consent` to `tests/contract/routes.contract.test.ts` with the same auth, validation and no-store assertions as its neighbours.
- E2E (Playwright): on the landing page, the primary button is disabled; ticking "Agree to all" enables it and ticks all five; unticking one optional item leaves the master indeterminate; "Read" opens the dialog, Escape closes it, focus returns; accepting only the required items proceeds; the Analytics script is absent until the analytics box is ticked; a version bump re-prompts.
- Accessibility: run an axe check on the landing page and on the open dialog.
- Finally run `npm run prisma:validate`, `npm run typecheck`, `npm test`, `npm run build`, `npm run test:e2e` and `npm run check:stubs`. All must pass.

## 9. Constraints

- Do not add payment, tracking or advertising code. Do not add any new third-party script.
- Do not change matching, notification content, or any file in `src/services/matching`.
- Do not edit the wording of the legal markdown. If you find the product does something the policies do not describe (or the policies describe something the product does not do), do not paper over it: list the mismatch in your final report.
- Keep new components under `src/components/consent/` and keep files small and typed. Follow the repo's lint rules.
- No em dashes in user-facing copy you write.

## 10. Final report

When done, report: files added and changed, the migration name, every environment variable that must now be set in Vercel (Production, Preview, Development), test results, and any mismatches between the policies and the actual behaviour. Do not report completion if any step above was skipped.
