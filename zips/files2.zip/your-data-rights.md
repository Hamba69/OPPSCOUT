---
title: Your Data Rights
slug: your-data-rights
version: 1.0.0
effective: "{{EFFECTIVE_DATE}}"
required: false
summary: Step-by-step guide to seeing, correcting, exporting, restricting and deleting your data.
---

# Your Data Rights

Effective {{EFFECTIVE_DATE}} · Version 1.0.0

Under the Data Protection and Privacy Act, 2019 of Uganda, your personal data is yours to see and control. This page tells you how to do each thing in practice.

## See and correct what we hold

Sign in and open your profile. Everything you gave us is there, and you can edit any of it. Your matches, saved opportunities and notification preferences are on their own pages.

## Get a copy

Write to {{CONTACT_EMAIL}} from the email address on your account with the subject "Data copy". We will reply with a file containing your profile, your matches, your saved opportunities and the log of alerts we have sent you. We respond within 30 days, and usually within a week.

## Delete your account

Write to {{CONTACT_EMAIL}} from your account address with the subject "Delete my account". We will confirm it is you, then erase your profile, matches, saved opportunities and notification history. The records of what you viewed or clicked are kept only as anonymous counts, with the link to you removed. We confirm by email when it is done. Deletion cannot be undone.

## Stop alerts or change channels

Open Settings. Switch off any channel, change how often we write, or turn alerts off completely. This is immediate.

## Withdraw a consent

You can withdraw consent for messaging or anonymous statistics at any time from Settings or from Cookie settings in the footer. Withdrawing does not affect anything we did before you withdrew, and it does not stop you using the core service.

## Object, restrict, or ask a question

If you object to a particular use of your data, or want us to pause using it while a dispute is sorted out, tell us what and why at {{CONTACT_EMAIL}}. We will either stop or explain the legal reason we cannot.

## What we may ask of you

To protect you, we confirm that a request really comes from you before we hand over or erase anything. We may ask you to reply from your account email or to confirm something only you would know. We do not ask for a copy of your national ID for this.

## If you are not satisfied

First tell us; we want the chance to put it right. If we do not, you may complain to the Personal Data Protection Office at the National Information Technology Authority, Uganda (NITA-U).
