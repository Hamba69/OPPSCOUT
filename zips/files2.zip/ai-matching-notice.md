---
title: How Matching Works (AI Notice)
slug: ai-matching-notice
version: 1.0.0
effective: "{{EFFECTIVE_DATE}}"
required: false
summary: How your matches are produced today, and the limits that apply if AI-assisted matching is ever turned on.
---

# How OppScout Matching Works

Effective {{EFFECTIVE_DATE}} · Version 1.0.0

You are entitled to know how a program ranks opportunities for you. This notice explains it, and it also sets the limits we hold ourselves to if we ever bring in an outside AI service.

## 1. Today: fixed rules, on our own servers

Your matches come from a deterministic engine we call OrbitMatch. Given the same profile and the same listing, it gives the same answer every time. No outside AI service sees your data.

It works in two steps. First comes the gate: education level, age limits and other hard requirements are checked, and if you do not meet one, the listing never appears in your feed, so you do not spend an evening on something you cannot get. Second comes the ranking: what passes the gate is scored on how closely your skills, field of study, location, experience, career interests and work-mode preference match what the listing asks for. Each match shows the factors that helped and the ones that are missing.

## 2. If AI-assisted matching is ever switched on

AI-assisted matching is built into the software but off. It will not be enabled until it has passed our own accuracy checks, and we will update this notice and ask for your agreement before it touches your data. If it is enabled, these limits apply:

- **What is shared.** Only your field of study, skills, work and internship experience, career interests, preferred locations and work-mode preference, along with the public text of the listing. Your name, email, phone number, date of birth and account identifiers are not sent.
- **Free text.** Experience entries are text you wrote. Do not put names of other people, ID numbers or sensitive details in them.
- **Who processes it.** A third-party AI provider, Anthropic, under terms that apply to business use of its service.
- **What it may change.** The AI can nudge a score by at most 10 points and write the plain-language reasons. It cannot decide education, certification, age or programme eligibility; those stay with the fixed rules.
- **If it fails.** If the AI service is slow or returns something unusable, your match falls back to the fixed rules, and you still get a result.

## 3. What matching never does

It never decides whether you are hired, funded or admitted. A person at the organization decides that. It never uses your religion, ethnicity, health, political views or similar sensitive attributes, because we do not collect them. A match score is a suggestion.

## 4. Disagree with a match?

Tell us. Use the report button on a listing, or write to {{CONTACT_EMAIL}} with the listing and what you think is wrong. A person will look at it. You can also improve results yourself by completing your profile, which raises the completeness score and gives the engine more to work with.
