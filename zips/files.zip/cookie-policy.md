---
title: Cookie Policy
slug: cookie-policy
version: 1.0.0
effective: "{{EFFECTIVE_DATE}}"
required: false
summary: The few cookies OppScout sets, what each one does, and how to control the optional ones.
---

# OppScout Cookie Policy

Effective {{EFFECTIVE_DATE}} · Version 1.0.0

OppScout uses very little. This page lists everything we place on your device, so you can check it against what your browser shows.

## 1. What a cookie is

A cookie is a small text file a website saves in your browser so it can recognise you on the next request. Some sites also use similar tools, such as local storage and session storage. We call all of these cookies here to keep things short. For how we handle personal data more broadly, see our Privacy Policy.

## 2. Cookies we always set

These are strictly necessary. Without them you could not stay signed in, and the site would not work. Because they are needed to deliver the service you asked for, they do not depend on your consent, and the consent screen does not offer a switch for them.

| Name | Set by | Purpose | Lifetime |
|---|---|---|---|
| `sb-{{SUPABASE_PROJECT_REF}}-auth-token` (sometimes split into numbered parts such as `.0` and `.1`) | OppScout, through our authentication provider Supabase | Keeps you signed in and lets the server confirm who you are on each request | Until you sign out or the session expires |
| `oppscout_consent` | OppScout | Remembers which documents you accepted, which version, and the choices you made on optional items, so we do not ask on every page | 12 months, or until we publish a new version of a document that needs your attention |

The sign-in cookie is set only after you create an account or sign in. Visitors who only read the landing page do not receive it. The consent cookie is set when you make a choice on the consent screen.

## 3. Optional measurement

If you tick the optional box that says you are happy to share anonymous usage and performance statistics, we load two tools from Vercel, our hosting provider.

**Web Analytics** counts page views and where visitors come from. **Speed Insights** measures how fast pages load on real devices. According to Vercel's published documentation, Web Analytics stores anonymised data and does not use cookies, and Speed Insights does not set persistent cookies. Neither tool is used to follow you from one website to another, and neither feeds advertising.

What they receive: the page address you visited, the referring site, rough location at country level, device type, browser and operating system, and load-time measurements. They do not receive your name, email, phone number or anything from your profile.

If you leave the box unticked, neither tool loads. If you tick it and later change your mind, open Cookie settings from the footer (or the Privacy section of your settings page) and switch it off. It stops at once for future visits.

## 4. Cookies we do not use

No advertising cookies. No social media plug-ins or tracking pixels. No cross-site tracking. No sale of browsing data. If that ever changes, we will update this page and ask for your consent first.

## 5. Controlling cookies

You can change your choices on optional items at any time from Cookie settings in the footer. Your browser also lets you view, block and delete cookies; the steps differ between Chrome, Firefox, Safari and the browsers built into some phones, so look for "site settings" or "privacy" in yours. If you block the sign-in cookie, you will not be able to stay signed in. If you clear the consent cookie, we will simply ask you again.

## 6. USSD and SMS

USSD sessions on a basic phone do not use cookies. They are identified by your phone number, a short-lived session that expires after five minutes, and your PIN. See the Messaging Terms for how that channel works.

## 7. Changes

If we add a cookie or a tool that changes this list, we will update this page, raise the version number, and ask for your choice again where the law requires it.

## 8. Questions

{{CONTACT_EMAIL}}
