---
title: Privacy Policy
slug: privacy-policy
version: 1.0.0
effective: "{{EFFECTIVE_DATE}}"
required: true
summary: What OppScout collects, why, who touches it, how long we keep it, and how to take it back.
---

# OppScout Privacy Policy

Effective {{EFFECTIVE_DATE}} · Version 1.0.0

OppScout helps people in Uganda find jobs, scholarships, grants and internships that fit them. To do that well we need to know a few things about you, and you should know exactly what we do with them. This policy says so in plain language. If anything here surprises you, write to us at {{CONTACT_EMAIL}} and we will explain.

## 1. Who is responsible for your data

{{LEGAL_ENTITY}} runs OppScout and is the data controller for the information described below. Our address is {{POSTAL_ADDRESS}}. Our registration with the Personal Data Protection Office is {{PDPO_REG_NO}}. Questions about your data go to our data protection contact, {{DPO_NAME}}, at {{CONTACT_EMAIL}}.

We handle personal data under the Data Protection and Privacy Act, 2019 of Uganda and its regulations. Where another law gives you stronger protection, that law applies.

## 2. What we collect

We collect only what the product needs. Here is the full list, grouped by where it comes from.

**What you give us when you sign up.** Your email address and a password. We never see your password in readable form; it is handled by our authentication provider. If you use USSD, we also hold your phone number and a PIN of four to six digits, and the PIN is stored only as a salted scrypt hash, so neither we nor our staff can read it back.

**What you give us in your profile.** Your name, plus anything you choose to add: phone number, date of birth, education level, institution, field of study, graduation status, skills, work and internship experience, certifications, where you live, where you would be willing to work, career interests, the categories of opportunity you want, whether you prefer remote, on-site or hybrid work, and the languages you speak. Only your name is needed to start. Everything else is optional, though the more you add, the better your matches become. We also calculate a profile completeness score from what you have filled in.

Your date of birth is used for one purpose: some opportunities have age limits, and we need it to tell you honestly whether you qualify. If you leave it blank, we cannot check age limits for you.

**What we generate about you.** A match score for each opportunity we compare you against, with the reasons it fits and what is missing. We keep these so your feed loads quickly and so you can see why something was suggested.

**What you do in the app.** The opportunities you save and whether you mark them as applied, the reminders we have sent about them, and your notification preferences (preferred channel, extra channels, frequency, on or off). When you view a listing, save it, click through to the official source, tell us you plan to apply, or report it, we record that action with the time it happened. We use these records to make the product better and to give organizations totals such as "42 people viewed this listing". We keep a log of every alert we send you: the channel, the message, when it was sent and whether it was delivered.

**What you tell us when you report a listing.** The reason you choose and any details you write. A person on our review team reads these.

**Technical data.** Our servers see your IP address and browser details whenever you connect, as every website does. We use them for security and to limit how many requests one person can make per minute. We do not build advertising profiles from them. If you allow it, we also collect anonymous page and performance statistics; see our Cookie Policy.

**What we do not collect.** We do not ask for your national ID number, bank details, mobile money PIN, religion, ethnicity, health information or political views, and no part of OppScout needs them. Please do not type them into free-text fields. We do not charge application fees and we will never ask you for money to access a listing.

## 3. Why we use it, and our legal basis

| What we do | Why | Basis |
|---|---|---|
| Create and secure your account | So you can sign in and keep your profile | Contract (providing the service you asked for) |
| Match you to opportunities and explain the match | This is the core product | Contract |
| Check eligibility, including age limits | So you are not shown things you cannot apply for | Contract |
| Send alerts by email, SMS, USSD inbox or in the app | To tell you about strong matches and approaching deadlines | Your consent, which you can withdraw at any time |
| Record views, saves, clicks and reports | To improve matching, spot suspicious listings, and report totals to organizations | Our legitimate interest in running a safe, useful service |
| Anonymous usage and performance statistics | To find slow pages and broken flows | Your consent |
| Prevent abuse and rate-limit requests | To keep the service available and safe | Legitimate interest |
| Keep records we are legally required to keep | To meet legal duties | Legal obligation |

We do not sell your personal data. We do not use it for advertising, and we do not let anyone else use it for advertising.

## 4. Automated matching

Your matches are produced by a program, not by a person reading your profile. The program first checks hard eligibility gates such as education level and age limits. If you fail a gate, the opportunity is left out of your feed. It then ranks what remains by how well your skills, field, location, experience, interests and work-mode preference line up. Every match shows its reasons so you can judge it yourself.

By default this runs on our own servers using fixed, published rules, with no outside AI service involved. If we ever switch on AI-assisted matching, we will tell you first and describe exactly what is shared; our AI Matching Notice explains the limits that would apply. A match is a suggestion. It never decides on your behalf whether you can apply, and a person at the organization, not us, makes every hiring or award decision.

## 5. Who else handles your data

We use a small number of service providers who process data on our instructions and for no purpose of their own.

- **Supabase** hosts our database, authentication and file storage.
- **Vercel** hosts the website and, if you allow it, provides anonymous analytics and performance measurement.
- **Resend** sends our emails, so it sees your email address and the email text.
- **Africa's Talking** carries our SMS messages and USSD sessions, so it and the mobile network see your phone number and the message content.
- **Upstash** keeps short-lived session data, USSD credentials and rate-limit counters in a Redis store.
- **Anthropic** would receive limited, non-identifying profile fields only if AI-assisted matching were switched on. It is off today.

Some of these companies run servers outside Uganda, which means your data can travel. When that happens we rely on contracts and safeguards that require the provider to protect it to a standard comparable to Ugandan law. Ask us if you want to know where your data is stored right now.

We may also disclose data if a court or a competent authority lawfully requires it, or to protect someone from serious harm. We will tell you when the law lets us.

**Organizations never see your profile.** Organizations that post opportunities get totals only: views, saves, clicks to the official source, and how many people said they plan to apply. They do not receive your name, phone, email, profile or any individual record. If we ever add a feature that lets you share your details with an organization, it will ask you every time, for that one organization, and nothing will be shared before you say yes.

## 6. How long we keep it

| Data | How long |
|---|---|
| Account and profile | For as long as your account is open |
| Matches, saved opportunities, notification history | For as long as your account is open, then deleted with it |
| Action records (views, saves, clicks) | While your account is open; when you delete it the link to you is removed and only anonymous counts remain |
| Reports you filed about listings | {{REPORT_RETENTION}} after the report is closed |
| Security and request logs | {{LOG_RETENTION}} |
| Inactive accounts | After {{INACTIVE_RETENTION}} without sign-in we email you, then delete the account if you do not respond within 30 days |

When you delete your account, your profile, matches, saved opportunities and notification history are erased. Action records are kept only after being disconnected from you, so totals shown to organizations and our own statistics do not change shape. Backups roll off within {{BACKUP_RETENTION}}.

## 7. Your rights

You have the right to know what we hold about you, to get a copy, to correct it, to have it erased, to object to particular uses, to withdraw consent, and to refuse direct marketing. You also have the right not to be subject to a significant decision made only by automated means; because no decision about you is made only by automated means here, this right is met by design.

Most of this you can do yourself. Your profile page lets you view and edit everything in it, and your settings page lets you turn alerts and each channel on or off. For a copy of your data or for deletion, write to {{CONTACT_EMAIL}} from the address on your account. We will confirm your identity and respond within 30 days, usually much sooner. Our Your Data Rights page walks through each request step by step.

If you think we have mishandled your data and we have not put it right, you may complain to the Personal Data Protection Office at the National Information Technology Authority, Uganda (NITA-U). We would like the chance to fix it first.

## 8. Security

Passwords are handled by our authentication provider and never stored by us in readable form. USSD PINs are salted and hashed. Data travels over encrypted connections. Access to personal data inside our team is limited by role, and organization accounts can reach only their own listings and totals. Requests are rate limited, and USSD sessions expire after five minutes with a lockout after three wrong PINs.

No system is perfectly safe. If a breach is likely to harm you, we will tell you and the Personal Data Protection Office without undue delay, and we will say what happened and what you can do.

## 9. Children

OppScout is for people aged 18 and over. We do not knowingly collect data from anyone younger. If you believe a child has created an account, write to {{CONTACT_EMAIL}} and we will close it and delete the data.

## 10. Messages we send

Alerts by email, SMS and USSD inbox are optional and off until you choose them. We send no more than {{DAILY_CAP}} alerts a day, and we do not repeat the same alert within 48 hours. Our Messaging Terms explain the rules, including how to stop them instantly.

## 11. Changes to this policy

When we change this policy in a way that matters, we will post the new version here with a new date and version number, and the next time you visit we will ask you to read and accept it again. Older versions are available on request.

## 12. Contact

{{LEGAL_ENTITY}}
{{POSTAL_ADDRESS}}
{{CONTACT_EMAIL}}
