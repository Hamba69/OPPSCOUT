---
title: Terms of Use
slug: terms-of-use
version: 1.0.0
effective: "{{EFFECTIVE_DATE}}"
required: true
summary: The rules for using OppScout, what we promise about listings, and what we cannot promise.
---

# OppScout Terms of Use

Effective {{EFFECTIVE_DATE}} · Version 1.0.0

These terms are the agreement between you and {{LEGAL_ENTITY}} ("we", "us") about your use of OppScout at {{APP_URL}}, through our USSD service and through any message we send you. By creating an account or ticking the box that says you accept them, you agree to them. If you do not agree, please do not use OppScout. Organizations that post opportunities accept separate provider terms in addition to these.

## 1. What OppScout is

OppScout is a discovery service. We collect jobs, scholarships, grants and internships, check them, and show you the ones that appear to fit your profile, with reasons. We are not an employer, a recruiter, a scholarship body or a funder. We do not take applications, and we do not decide who gets anything. When you apply, you do it on the organization's own channel, and the organization alone decides the outcome.

## 2. Who can use it

You must be at least 18 years old and able to enter a binding agreement. You may use OppScout only for yourself. If we learn that an account belongs to someone under 18, we will close it.

## 3. Your account

Give us true information and keep it current, because matches and age-limit checks depend on it. Keep your password and your USSD PIN to yourself; you are responsible for what happens under your account, and you should tell us at {{CONTACT_EMAIL}} at once if you think someone else has got in. One person, one account. Do not use someone else's details, and do not create accounts to get around a limit or a suspension.

## 4. What we promise about listings, and what we cannot

Before a listing reaches you we try to confirm the official source, the deadline and that it is not a duplicate. Listings that ask for payment or sensitive personal details are held back for review. Each listing links to the organization's own page so you can verify it yourself, and a "verified" badge means a reviewer checked those things at a particular time.

That is the extent of it. Deadlines move, organizations change their requirements, and a listing that was sound when we checked it can change afterwards. A match score and an "eligible" tag are our best reading of the information available; they are not a guarantee that you qualify, that you will be shortlisted or that you will be chosen. Read the official notice before you apply, and do not rely on us alone for a deadline that matters.

**No real opportunity charges you to apply.** If a listing, or anyone claiming to act for an organization, asks you for money, mobile money, a "processing" fee or a copy of your national ID before you have been offered anything, treat it as a scam. Use the report button on the listing or write to {{CONTACT_EMAIL}}. We would rather have ten false alarms than one missed scam.

## 5. Cost

OppScout is free for people looking for opportunities. If we ever add paid features, they will be optional, they will be announced to you first, and the core service of discovering and matching opportunities will stay free. We will never charge you for something without asking you first.

## 6. How you may use it

Use OppScout honestly. You agree not to:

- put false or misleading information in your profile, or impersonate another person or organization;
- post, submit or report anything you know to be untrue, unlawful, abusive or fraudulent;
- scrape, copy or republish our catalogue in bulk, or use automated tools to collect data from the service, without our written permission;
- probe, overload, bypass or interfere with our security, rate limits or other users' access;
- try to find out other people's personal data, or use OppScout to harass, spam or market to anyone;
- use the service to break any law of Uganda, including the Computer Misuse Act.

## 7. Reports and our review

When you report a listing, you are helping other people, so please be accurate and fair. We may remove listings, hold them for review, or suspend accounts that break these terms. We will usually tell you why, unless the law or someone's safety says otherwise.

## 8. Our content and yours

The OppScout name, logo, design, software and the way we organise the catalogue belong to {{LEGAL_ENTITY}} or its licensors. You may use them to use the service, and for nothing else. Opportunity text belongs to the organizations that published it, and we show it with a link back to the source.

What you put in your profile stays yours. You give us permission to store it and to use it for the purposes in our Privacy Policy, no more. That permission ends when you delete your account, subject to the retention periods set out there.

## 9. Third-party links and services

Listings link to websites we do not run. We are not responsible for what you find there, for their privacy practices or for what they ask of you. Messages by SMS, USSD and email pass through telecom and email providers whose service we do not control, so delivery can be late or can fail.

## 10. Availability

We work to keep OppScout running, but we do not promise it will always be available or error-free. We may change, pause or stop parts of it, and where a change affects you materially we will give notice where we reasonably can.

## 11. Limits on our responsibility

We provide OppScout "as is". To the extent the law allows, we are not liable for loss that comes from a missed or changed deadline, from a decision by an organization, from a scam run by a third party outside our platform, or from using information in a listing without checking it at the source. Nothing in these terms limits liability that cannot lawfully be limited, including for fraud or for death or personal injury caused by negligence, and nothing here takes away any right you have under Ugandan consumer or data protection law.

## 12. Ending your account

You can stop using OppScout at any time and ask us to delete your account; see Your Data Rights. We may suspend or close an account that breaks these terms or puts others at risk, and we will say why where we can.

## 13. Changes

We may update these terms. If a change is significant, we will post the new version with a new version number and ask you to accept it again before you continue. Using the service after that means you accept the new version.

## 14. Law and disputes

These terms are governed by the laws of Uganda. If we cannot settle a disagreement by talking, the courts of Uganda have jurisdiction. Please write to us first at {{CONTACT_EMAIL}}; most problems are quicker to solve that way.

## 15. Contact

{{LEGAL_ENTITY}}
{{POSTAL_ADDRESS}}
{{CONTACT_EMAIL}}
