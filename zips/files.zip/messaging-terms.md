---
title: Messaging and USSD Terms
slug: messaging-terms
version: 1.0.0
effective: "{{EFFECTIVE_DATE}}"
required: false
summary: How alerts by email, SMS, USSD and in-app work, how often they come, what they cost you, and how to stop them.
---

# OppScout Messaging and USSD Terms

Effective {{EFFECTIVE_DATE}} · Version 1.0.0

These terms cover the alerts OppScout sends and the USSD service you can dial. They apply only if you choose to receive alerts or use USSD. They sit alongside our Terms of Use and Privacy Policy.

## 1. Your choice

Alerts are optional. You decide which channels you want (email, SMS, USSD inbox, or in the app only), which one is your main channel, how often you want to hear from us (instantly, daily or weekly), and whether alerts are on at all. You make these choices in Settings, and you can change them whenever you like. Ticking the messaging box on the consent screen means you agree that we may contact you through the channels you pick. It is separate from accepting the Terms and the Privacy Policy, and you can use OppScout without it.

## 2. What we send

We send an alert when a strong match appears, when a deadline is close on an opportunity that fits you or that you saved (we aim for about seven days, three days and one day before), and when something you saved changes after you saved it, for example a moved deadline. If you have been away for about a week we may send one digest in place of several separate alerts. Every message names the opportunity and, where there is room, links to the official source.

We will not send adverts, third-party promotions or messages unrelated to opportunities. We will not ask for money, a PIN, a password or an ID number in any message. If a message claiming to be from OppScout asks for any of these, it is not from us; please forward it to {{CONTACT_EMAIL}}.

## 3. How many

By default we send no more than {{DAILY_CAP}} alerts to you in a day, and we do not repeat the same alert within 48 hours. If more things than that deserve your attention, they wait for the next day or fold into a digest.

## 4. Email

Email goes to the address on your account through our email provider, Resend. Messages come from {{EMAIL_FROM}}. If one lands in spam, marking it "not spam" helps later ones arrive.

## 5. SMS

SMS goes to the phone number in your profile through Africa's Talking and your mobile network. We do not charge you for receiving them, but your network may in some circumstances, and standard roaming rules apply abroad. Delivery depends on the network and can be delayed or fail; we record whether each message was delivered but cannot guarantee it. Keep your number current, because a recycled number could send your alerts to someone else. To stop SMS, turn it off in Settings or write to {{CONTACT_EMAIL}} and we will switch it off within one working day.

## 6. USSD

You can reach OppScout from any phone, including a basic one with no data, by dialling {{USSD_CODE}}. You sign in with your phone number and a PIN of four to six digits.

- **Your PIN.** Choose one that is hard to guess, do not share it, and do not use a PIN you use for mobile money or a bank. We store it only as a salted hash and cannot read it. After three wrong attempts the session ends and you will need to start again.
- **Sessions.** A USSD session closes after five minutes of inactivity. Anything unsaved in the session is lost.
- **What you see.** Because USSD screens are tiny, a USSD message holds a short summary, up to three matches at a time. For the full listing, follow the official link on the web or in an SMS.
- **Cost.** Network charges for USSD vary by operator and are set by them, not by us. Check with your operator.
- **Your number.** We tie USSD access to the phone number on your account. If you lose the phone or change numbers, update your profile, and write to us if you think someone else has your SIM.

## 7. Stopping

Open Settings and switch off a channel or all alerts, or tell us at {{CONTACT_EMAIL}}. Turning off alerts does not delete your account; you can still use the site and see your matches there. If you want everything gone, see Your Data Rights.

## 8. Telecom rules

We send messages in line with the rules of the Uganda Communications Commission and of the mobile network operators and aggregators we use. They may suspend or filter messages that break their rules, and we may change message content or timing to comply.

## 9. Changes

If we add a new alert type or a new channel, we will update this page and ask for your agreement again before sending anything new.

## 10. Contact

{{CONTACT_EMAIL}}
